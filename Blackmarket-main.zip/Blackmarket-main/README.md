## Blackmarket-V2
The bare bones of a fully functional location changing crypto blackmarket with easy to use config and qb-target

/market - Test Command (Disabled in config)

## Screenshot

![Screenshot 2022-03-02 144131](https://user-images.githubusercontent.com/82594996/156391897-07c1dced-46bd-490c-9ea5-abab8f83fd19.jpg)

---

## Dependencies 

qb-target - https://github.com/BerkieBb/qb-target
qb-core - https://github.com/qbcore-framework/qb-core

---

## License 

```
Blackmarket-V2
Copyright (C) 2022  HUB Development

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
```
